package com.example.practica

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.practica.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    var contadorVidas = 0
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        enableEdgeToEdge()
        Log.i("MainActivity", "onCreate - Creando la aplicacion")

        // Compartir texto
        binding.buttonText.setOnClickListener {
            val text = binding.inputText.text.toString().trim()

            // Evitar texto vacio
            if (text.isEmpty()) {
                Toast.makeText(this, "Escriba un mensajes antes de tener que compartir", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Intent para compartir
            val intent = Intent(Intent.ACTION_SEND).apply {
                putExtra(Intent.EXTRA_TEXT, text)
                type = "text/plain"
            }

            // Validacion para ver si hay apps que lo manejan
            val packageManager = packageManager
            if (intent.resolveActivity(packageManager) != null) {

                // Ventana para compartir
                val chooser = Intent.createChooser(intent, "Compartir por...")
                startActivity(chooser)
            } else {
                Toast.makeText(this, "No hay aplicaciones disponibles para compartir", Toast.LENGTH_SHORT).show()
            }
        }

        // Abrir enlace por navegador
        binding.buttonUrl.setOnClickListener {
            var url = binding.inputUrl.text.toString().trim()

            // Validar que el input no este vacio
            if (url.isEmpty()) {
                Toast.makeText(this, "Ingrese una URL", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            //  Agregar http:// o https:// si falta
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://$url"
            }

            if (!android.util.Patterns.WEB_URL.matcher(url).matches()) {
                Toast.makeText(this, "URL invalida", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = android.net.Uri.parse(url)
            }

            // Validacion para comprobar si hay alguna aplicacion que se pueda utilizar la URL
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "No hay navegador disponible", Toast.LENGTH_SHORT).show()
            }
        }

        // Geolocalizacion
        binding.buttonLocation.setOnClickListener {
            val location = binding.inputLocation.text.toString().trim()

            // Validar si el input esta vacio
            if (location.isEmpty()) {
                Toast.makeText(this, "Ingrese una ubicacion", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val encodedLocation = android.net.Uri.encode(location)

            // Esquema geografico
            val uri = android.net.Uri.parse("geo:0,0?q=$encodedLocation")

            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = uri
            }

            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "No hay aplicaciones de mapas disponibles en el telefono", Toast.LENGTH_SHORT).show()
            }
        }

        // Llamadas
        binding.buttonCall.setOnClickListener {
            var number = binding.inputCall.text.toString().trim()

            // Validacion si el input esta vacio
            if (number.isEmpty()) {
                Toast.makeText(this, "Ingrese un número telefónico", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            number = number.replace(" ", "")
                .replace("-", "")
                .replace("(", "")
                .replace(")", "")

            val uri = android.net.Uri.parse("tel:$number")

            /* Se utiliza ACTION_DIAL debido a que la aplicacion abre la aplicacion de marcado de
            telefono con el numero cargado pero no llama inmediatamente, eso lo elige el usuario */

            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = uri
            }

            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "No hay aplicaciones de telefono disponibles", Toast.LENGTH_SHORT).show()
            }
        }

        binding.imageButton.setOnClickListener {
            binding.progressBar.visibility = View.VISIBLE

            // Lanzar cámara
            takePictureLauncher.launch(null)
        }

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    override fun onStart() {
        super.onStart()
        Log.i("MainActivity", "onStart - Aplicacion comenzando")
    }

    override fun onResume() {
        super.onResume()
        Log.i("MainActivity", "onResume - Retomando aplicacion")
        contadorVidas++
        Log.i("MainActivity","Estado: onResume ejecutándose - Resurrección número: $contadorVidas")
    }

    override fun onPause() {
        super.onPause()
        Log.i("MainActivity", "onPause - Aplicacion en pausa")
    }

    override fun onStop() {
        super.onStop()
        Log.i("MainActivity", "onStop - Aplicacion detenida")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("MainActivity", "onDestroy - Aplicacion destruida")
    }

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->

        // Ocultar carga
        binding.progressBar.postDelayed({
            binding.progressBar.visibility = View.GONE
        }, 1000)

        if (bitmap != null) {
            binding.imageView.setImageBitmap(bitmap)
        } else {
            Toast.makeText(this, "No se pudo tomar la foto", Toast.LENGTH_SHORT).show()
        }
    }
}